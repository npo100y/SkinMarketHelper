﻿namespace SkinMarketHelper.ViewModels
{
    public class SortOption
    {
        public string DisplayName { get; set; }
        public string Value { get; set; }
    }
}
